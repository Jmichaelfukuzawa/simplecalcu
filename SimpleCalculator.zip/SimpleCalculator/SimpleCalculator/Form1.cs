﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCalculator
{
    public partial class SimpleCalculator : Form
    {
        public SimpleCalculator()
        {
            InitializeComponent();
                        operationComboBox.SelectedItem = "+";

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void operationComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void secondNumberTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void resultTextBox_TextChanged(object sender, EventArgs e)
        {
            resultTextBox.Focus();

        }

        private void computeResultButton_Click(object sender, EventArgs e)
        {
            try
            {
                double firstNumber = double.Parse(firstNumberTextBox.Text);
                double secondNumber = double.Parse(secondNumberTextBox.Text);

                switch (operationComboBox.SelectedItem.ToString())
                {
                    case "+":
                        resultTextBox.Text = (firstNumber + secondNumber).ToString();
                        break;
                    case "-":
                        resultTextBox.Text = (firstNumber - secondNumber).ToString();
                        break;
                    case "*":
                        resultTextBox.Text = (firstNumber * secondNumber).ToString();
                        break;
                    case "/":
                        if (secondNumber != 0)
                        {
                            resultTextBox.Text = (firstNumber / secondNumber).ToString();
                        }
                        else
                        {
                            resultTextBox.Text = "Cannot divide by zero";
                        }
                        break;
                    default:
                        resultTextBox.Text = "Invalid operation";
                        break;
                }
            }
            catch (FormatException)
            {
                resultTextBox.Text = "Invalid input. Please enter valid numbers.";
            }
        
    }
    }
}
